file.symlink(
  from = ...,
  to = 'data'
)
