# configure git

git config --global user.name ...
git config --global user.email ...
git commit --no-edit --amend --reset-author

# Link your local repository to the origin repository on GitHub, by
# copying the code shown on your GitHub repo under the heading:
# "…or push an existing repository from the command line"
