# Configure git

# This line is only needed if you are not using a SESYNC server
git config --global init.defaultBranch main 


git config --global user.name ...
git config --global user.email ...

# Link your local repository to the origin repository on GitHub, by
# copying the code shown on your GitHub repo under the heading:
# "…or push an existing repository from the command line"
